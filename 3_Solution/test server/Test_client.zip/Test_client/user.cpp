#include "user.h"

User::User() {}
void User::addUsername(const QString u)
{
    username=u;
}
